package minhas;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
//import org.apache.commons.fileupload.FileItem;
//import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.FileUploadException;
//import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
//import org.omg.CORBA_2_3.portable.InputStream;
import java.sql.*;
public class Set extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * Constructor of the object.
	 */
	public Set() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out
				.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the GET method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
String arr="";
String p="",fileName="";
		response.setContentType("text/html");
		
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		if(isMultipart)
		{ServletFileUpload upload=new ServletFileUpload();
			try{
				FileItemIterator itr=upload.getItemIterator(request);
					while(itr.hasNext())
					{
						FileItemStream item=itr.next();
							if(item.isFormField())
								{	String FieldName=item.getFieldName();
									
									InputStream is=(InputStream) item.openStream();
									byte[] b=new byte[is.available()];
									is.read(b);
									String value=new String(b);
									response.getWriter().println(FieldName+":"+value+"<br/>");
									arr=value;
								}
							else
							{fileName = item.getName();
								String path="C:/Users/user/Workspaces/MyEclipse 8.5/minhas/the/WebRoot/";
								
									if(FileUpload.processFile(path,item))
									{
										response.getWriter().println("file uploaded successsfully");
										//response.getWriter().println(path);
										
										p=path+"img\\"+fileName;
										response.getWriter().println(p);
										
									}
									else
										response.getWriter().println("file uploading failed");
					
							}//esecomplete
					}//whilecomplete
					 try{ HttpSession sign = request.getSession();
				     String email=(String)sign.getAttribute("email"); 
				     String a=(String)sign.getAttribute("a");
				     String name=(String)sign.getAttribute("name");
				     String pic=(String)sign.getAttribute("pic");
						 Class.forName("com.mysql.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","root");
						
						String query="insert into status(email,file,status,name,npic,li) values(?,?,?,?,?,?)";
						PreparedStatement ps=con.prepareStatement(query);
						ps.setString(1,email);
						ps.setString(2,p);
						ps.setString(3,arr);
						ps.setString(4,name);
						ps.setString(5,pic);
						ps.setInt(6,0);
						int rs=ps.executeUpdate();
					System.out.print(arr);
						if(rs>0)
						{ if(a.equals("admin"))
						response.sendRedirect("admin.jsp");
						else
						response.sendRedirect("../user.jsp");
						}
						else{
						response.sendRedirect("../addpost.jsp");
						}
						}catch(Exception e)
						{ e.printStackTrace();
						System.out.println(e);
					response.sendRedirect("../addpost.jsp");
						}
			
			}//try comp
			catch(FileUploadException fue)
			{fue.printStackTrace();
		
			}
		}
		
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
