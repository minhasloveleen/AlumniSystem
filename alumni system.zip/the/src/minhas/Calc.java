package minhas;
import java.sql.*;

public class Calc {
	public static void p(int sno ,int like)
	{
	try{like++;
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","root");
		
		String query="Update status set like=? where sno=?";
		PreparedStatement ps=con.prepareStatement(query);
		ps.setInt(1,like);
		ps.setInt(2,sno);
		int r=ps.executeUpdate();
		System.out.print(r);
		//return true;
	}
	catch(Exception e)
	{
		//return true;
	}
		
	
	}
}
